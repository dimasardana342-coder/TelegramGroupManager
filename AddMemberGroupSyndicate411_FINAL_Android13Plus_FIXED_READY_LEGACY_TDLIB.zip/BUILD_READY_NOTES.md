Build-ready source package for Add Member Group Syndicate 411.
TDLib dependency: com.github.tdlibx:td:1.8.56 via JitPack.
