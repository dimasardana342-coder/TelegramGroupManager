# Add Member Group Syndicate 411 — Final Specification

Target Android: 13+

## Member organization
- Contacts are sorted alphabetically A–Z before assignment.
- A single cycle contains 30 consented contacts.
- Group 1 receives positions 1–10.
- Group 2 receives positions 11–20.
- Group 3 receives positions 21–30.
- A contact successfully processed for one group is excluded from later groups in the same cycle.
- Contacts Telegram says cannot be added are skipped and recorded with their status/reason when available.

## Account/group state
- Up to 10 Telegram account slots.
- Account state and cooldown are independent.
- Changing the selected account or group does not reset another account's timer.
- Moving to the next group is manual.
- The app must not automatically start a new group or cycle after a cooldown.

## Timing
- The UI should enforce the configured cooldowns and warn when a user tries to act before a cooldown expires.
- Inter-member automation must remain limited to consent-based workflows and must stop/obey Telegram rate limits rather than attempting to bypass them.

## Login
- Telegram login is performed through TDLib.
- API ID/API Hash and account verification credentials are supplied by the user in the app; never hard-code private credentials.
