package com.example.telegramgroupmanager

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

private data class AccountUi(
    val id: Int,
    val status: String = "Belum terhubung",
    val connected: Boolean = false,
    val done: Int = 0,
    val failed: Int = 0,
    val nextActionAt: Long = 0L,
    val groupCooldownUntil: Long = 0L,
    val cycleCooldownUntil: Long = 0L
)

private fun createChannel(context: Context) {
    if (Build.VERSION.SDK_INT >= 26) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("tgm", "Syndicate 411", NotificationManager.IMPORTANCE_DEFAULT))
    }
}

@Composable
fun App(context: Context) {
    val prefs = remember { context.getSharedPreferences("state", Context.MODE_PRIVATE) }
    var apiId by remember { mutableStateOf(prefs.getString("apiId", "") ?: "") }
    var apiHash by remember { mutableStateOf(prefs.getString("apiHash", "") ?: "") }
    var group1 by remember { mutableStateOf(prefs.getString("group1", "") ?: "") }
    var group2 by remember { mutableStateOf(prefs.getString("group2", "") ?: "") }
    var group3 by remember { mutableStateOf(prefs.getString("group3", "") ?: "") }
    var contactsText by remember { mutableStateOf("") }
    var selectedAccount by remember { mutableStateOf(1) }
    var selectedGroup by remember { mutableStateOf(1) }
    var consentConfirmed by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Siap. Gunakan hanya untuk anggota yang memang sudah menyetujui penambahan ke grup.") }
    var dialogSlot by remember { mutableStateOf<Int?>(null) }
    var phoneInput by remember { mutableStateOf("") }
    var codeInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }
    var authInputType by remember { mutableStateOf("PHONE") }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    val accounts = remember {
        mutableStateListOf<AccountUi>().apply {
            repeat(10) { i ->
                val id = i + 1
                add(AccountUi(
                    id = id,
                    done = prefs.getInt("a${id}_done", 0),
                    failed = prefs.getInt("a${id}_failed", 0),
                    nextActionAt = prefs.getLong("a${id}_next", 0L),
                    groupCooldownUntil = prefs.getLong("a${id}_group", 0L),
                    cycleCooldownUntil = prefs.getLong("a${id}_cycle", 0L)
                ))
            }
        }
    }
    val managers = remember { mutableStateMapOf<Int, TdLibAccount>() }

    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }

    fun saveAccount(a: AccountUi) {
        prefs.edit()
            .putInt("a${a.id}_done", a.done)
            .putInt("a${a.id}_failed", a.failed)
            .putLong("a${a.id}_next", a.nextActionAt)
            .putLong("a${a.id}_group", a.groupCooldownUntil)
            .putLong("a${a.id}_cycle", a.cycleCooldownUntil)
            .apply()
    }

    val accountIndex = accounts.indexOfFirst { it.id == selectedAccount }
    val account = accounts[accountIndex]
    val hardCooldown = maxOf(account.groupCooldownUntil, account.cycleCooldownUntil)
    val waitRemaining = maxOf(account.nextActionAt, hardCooldown) - now
    val contacts = contactsText.lines().map { it.trim().removePrefix("@").trim() }.filter { it.isNotBlank() }.distinct().sortedWith(String.CASE_INSENSITIVE_ORDER)
    val groupName = when (selectedGroup) { 1 -> group1; 2 -> group2; else -> group3 }
    val completedThisAccount = account.done + account.failed

    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF129BFF), secondary = Color(0xFF00D8FF))) {
        Box(Modifier.fillMaxSize()) {
            Image(painterResource(R.drawable.syndicate_bg), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .70f)))
            Scaffold(containerColor = Color.Transparent, topBar = { TopAppBar(title = { Text("ADD MEMBER GROUP SYNDICATE 411") }) }) { pad ->
                LazyColumn(Modifier.padding(pad).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = .78f))) {
                            Column(Modifier.padding(14.dp)) {
                                Text("MANUAL • CONSENT-BASED", style = MaterialTheme.typography.titleLarge)
                                Text("Aplikasi tidak menjalankan penambahan massal tanpa tindakan Anda. Setiap target harus memang telah menyetujui penambahan.", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    item {
                        OutlinedTextField(apiId, { apiId = it; prefs.edit().putString("apiId", it).apply() }, Modifier.fillMaxWidth(), label = { Text("Telegram API ID") })
                        Spacer(Modifier.height(6.dp))
                        OutlinedTextField(apiHash, { apiHash = it; prefs.edit().putString("apiHash", it).apply() }, Modifier.fillMaxWidth(), label = { Text("Telegram API Hash") })
                    }
                    item {
                        Text("Grup", style = MaterialTheme.typography.titleMedium)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(1,2,3).forEach { g -> FilterChip(selectedGroup == g, { selectedGroup = g }, { Text("Grup $g") }) }
                        }
                        Spacer(Modifier.height(6.dp))
                        OutlinedTextField(
                            value = groupName,
                            onValueChange = { v ->
                                when (selectedGroup) { 1 -> { group1 = v; prefs.edit().putString("group1", v).apply() }; 2 -> { group2 = v; prefs.edit().putString("group2", v).apply() }; 3 -> { group3 = v; prefs.edit().putString("group3", v).apply() } }
                            }, Modifier.fillMaxWidth(), label = { Text("@username grup atau Chat ID") }
                        )
                    }
                    item {
                        Text("Pilih akun", style = MaterialTheme.typography.titleMedium)
                        (0..1).forEach { row ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                (1..5).forEach { offset -> val id = row * 5 + offset; FilterChip(selectedAccount == id, { selectedAccount = id }, { Text("A$id") }) }
                            }
                        }
                    }
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = .80f))) {
                            Column(Modifier.padding(14.dp)) {
                                Text("Akun $selectedAccount • ${account.status}", style = MaterialTheme.typography.titleMedium)
                                Text("Berhasil: ${account.done} • Gagal/skip: ${account.failed} • Total diproses: $completedThisAccount")
                                if (waitRemaining > 0) Text("TUNGGU: ${waitRemaining / 3600000}j ${(waitRemaining / 60000) % 60}m ${(waitRemaining / 1000) % 60}d")
                                else Text("Status waktu: SIAP")
                            }
                        }
                    }
                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                val id = apiId.toIntOrNull()
                                if (id == null || apiHash.isBlank()) status = "Masukkan API ID dan API Hash terlebih dahulu."
                                else {
                                    prefs.edit().putString("apiId", apiId).putString("apiHash", apiHash).apply()
                                    managers[selectedAccount]?.close()
                                    val manager = TdLibAccount(context, selectedAccount, id, apiHash,
                                        { msg -> status = msg },
                                        { auth ->
                                            val idx = accounts.indexOfFirst { it.id == selectedAccount }
                                            if (idx >= 0) accounts[idx] = accounts[idx].copy(connected = auth == "READY", status = when(auth) { "READY" -> "TERHUBUNG"; "PHONE" -> "Menunggu nomor"; "CODE" -> "Menunggu kode"; "PASSWORD" -> "Menunggu password 2FA"; else -> accounts[idx].status })
                                            if (auth == "PHONE" || auth == "CODE" || auth == "PASSWORD") { authInputType = auth; dialogSlot = selectedAccount }
                                        })
                                    managers[selectedAccount] = manager
                                    manager.start()
                                }
                            }, Modifier.weight(1f)) { Text("LOGIN / HUBUNGKAN") }
                            OutlinedButton(onClick = { managers[selectedAccount]?.close(); status = "Akun $selectedAccount diputuskan." }, Modifier.weight(1f)) { Text("PUTUS") }
                        }
                    }
                    item {
                        Text("Daftar kontak (maks. 30)", style = MaterialTheme.typography.titleMedium)
                        OutlinedTextField(contactsText, { contactsText = it }, Modifier.fillMaxWidth().height(180.dp), label = { Text("Satu username per baris") }, placeholder = { Text("@Andi\n@Budi\n@Citra") })
                        Text("A–Z: posisi 1–10 → Grup 1, 11–20 → Grup 2, 21–30 → Grup 3. Daftar ini hanya pengurutan; Anda tetap menekan tombol untuk setiap penambahan.", style = MaterialTheme.typography.bodySmall)
                    }
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(consentConfirmed, { consentConfirmed = it })
                            Text("Saya memastikan semua kontak yang diproses telah menyetujui penambahan ke grup.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    item {
                        val shown = contacts.drop((selectedGroup - 1) * 10).take(10)
                        Text("Grup $selectedGroup • ${shown.size}/10 kontak", style = MaterialTheme.typography.titleMedium)
                        shown.forEachIndexed { i, u -> Text("${i + 1 + (selectedGroup - 1) * 10}. @$u") }
                        Spacer(Modifier.height(6.dp))
                        Button(
                            enabled = account.connected && consentConfirmed && groupName.isNotBlank() && shown.isNotEmpty() && waitRemaining <= 0,
                            onClick = {
                                val target = shown.firstOrNull { !prefs.getBoolean("done_${selectedAccount}_${it}", false) && !prefs.getBoolean("skip_${selectedAccount}_${it}", false) }
                                if (target == null) {
                                    status = "Tidak ada kontak baru pada Grup $selectedGroup."
                                } else {
                                    status = "Memproses @$target..."
                                    managers[selectedAccount]?.addMember(groupName, target) { result ->
                                        val ok = result.startsWith("BERHASIL")
                                        prefs.edit().putBoolean("${if (ok) "done" else "skip"}_${selectedAccount}_${target}", true).apply()
                                        val old = accounts[accountIndex]
                                        val updated = if (ok) old.copy(done = old.done + 1) else old.copy(failed = old.failed + 1)
                                        val groupCount = (0 until 10).count { j -> val u = shown.getOrNull(j); u != null && (prefs.getBoolean("done_${selectedAccount}_${u}", false) || prefs.getBoolean("skip_${selectedAccount}_${u}", false)) }
                                        val final = if (groupCount >= 10) updated.copy(groupCooldownUntil = System.currentTimeMillis() + 5 * 60 * 1000L) else updated.copy(nextActionAt = System.currentTimeMillis() + 5000L)
                                        accounts[accountIndex] = final.copy(status = if (groupCount >= 10) "COOLDOWN 5 MENIT • Grup $selectedGroup selesai" else "SIAP")
                                        saveAccount(accounts[accountIndex])
                                        status = result + if (groupCount >= 10) " Grup $selectedGroup selesai. Tunggu 5 menit, lalu pilih grup berikutnya secara manual." else " Tunggu 5 detik sebelum percobaan berikutnya."
                                    }
                                }
                            }, Modifier.fillMaxWidth()
                        ) { Text(if (waitRemaining > 0) "TUNGGU ${waitRemaining / 1000}s" else "TAMBAH 1 KONTAK") }
                    }
                    item {
                        OutlinedButton(onClick = {
                            if (completedThisAccount >= 30) {
                                accounts[accountIndex] = account.copy(cycleCooldownUntil = System.currentTimeMillis() + 6 * 60 * 60 * 1000L, status = "COOLDOWN 6 JAM")
                                saveAccount(accounts[accountIndex])
                                status = "Cooldown siklus 6 jam dimulai. Setelah selesai, lanjutkan secara manual."
                            } else status = "Siklus belum mencapai 30 proses pada akun ini."
                        }, Modifier.fillMaxWidth()) { Text("SELESAI SIKLUS / MULAI COOLDOWN 6 JAM") }
                    }
                    item { Text(status, style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
    }

    if (dialogSlot != null) {
        AlertDialog(onDismissRequest = { dialogSlot = null }, title = { Text("Login akun $dialogSlot") }, text = {
            Column {
                Text("Tahap: $authInputType")
                Spacer(Modifier.height(8.dp))
                when (authInputType) {
                    "PHONE" -> OutlinedTextField(phoneInput, { phoneInput = it }, Modifier.fillMaxWidth(), label = { Text("Nomor Telegram +62...") })
                    "CODE" -> OutlinedTextField(codeInput, { codeInput = it }, Modifier.fillMaxWidth(), label = { Text("Kode Telegram") })
                    "PASSWORD" -> OutlinedTextField(passwordInput, { passwordInput = it }, Modifier.fillMaxWidth(), label = { Text("Password 2FA") }, visualTransformation = PasswordVisualTransformation())
                }
            }
        }, confirmButton = { TextButton(onClick = {
            val slot = dialogSlot ?: return@TextButton
            when (authInputType) { "PHONE" -> managers[slot]?.setPhone(phoneInput); "CODE" -> managers[slot]?.setCode(codeInput); "PASSWORD" -> managers[slot]?.setPassword(passwordInput) }
            dialogSlot = null
        }) { Text("Kirim") } }, dismissButton = { TextButton(onClick = { dialogSlot = null }) { Text("Tutup") } })
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel(applicationContext)
        setContent { App(applicationContext) }
    }
}
