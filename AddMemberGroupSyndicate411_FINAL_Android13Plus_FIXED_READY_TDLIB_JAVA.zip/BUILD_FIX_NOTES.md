# Build fix 2

The previous revision still used the legacy Android package `org.drinkless.td.libcore.telegram.*`.
The tdlibx JitPack library is based on TDLib Java bindings under `org.drinkless.tdlib.*`.
This revision switches `TdLibAccount.kt` to that package, uses the generated `TdlibParameters` no-arg form with named fields, and closes the client through `TdApi.Close()` rather than the removed `Client.close()`.

Dependency: `com.github.tdlibx:td:1.8.56` via JitPack.
