# Add Member Group Syndicate 411 — v3.0

Android 16 / Kotlin / Compose / TDLib.

Features: up to 10 Telegram account slots, per-account TDLib login, selectable group, direct-add of individual usernames, per-account counters, 5-second guard between manual attempts, 10-attempt cooldown of 6 hours, manual continuation, and 6-hour cooldown after completing 20 attempts. The Syndicate image is used as the app background.

Use direct-add only for contacts who have explicitly agreed to be added and only where the Telegram account has the required admin rights. The app does not bypass Telegram limits or automatically continue after cooldown.
