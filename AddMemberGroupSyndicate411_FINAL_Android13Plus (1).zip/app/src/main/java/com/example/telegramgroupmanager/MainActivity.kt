package com.example.telegramgroupmanager

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

private data class AccountUi(
    val id: Int,
    val status: String = "Belum terhubung",
    val connected: Boolean = false,
    val done: Int = 0,
    val failed: Int = 0,
    val cooldownUntil: Long = 0L
)

private fun createChannel(context: Context) {
    if (Build.VERSION.SDK_INT >= 26) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("tgm", "Add Member Group Syndicate 411", NotificationManager.IMPORTANCE_DEFAULT))
    }
}

@Composable
fun App(context: Context) {
    var apiId by remember { mutableStateOf("") }
    var apiHash by remember { mutableStateOf("") }
    var group by remember { mutableStateOf("") }
    var selectedAccount by remember { mutableStateOf(1) }
    var status by remember { mutableStateOf("Siap. Tambahkan hanya kontak yang memang telah menyetujui penambahan.") }
    var dialogSlot by remember { mutableStateOf<Int?>(null) }
    var phoneInput by remember { mutableStateOf("") }
    var codeInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }
    var authInputType by remember { mutableStateOf("PHONE") }
    var username by remember { mutableStateOf("") }
    var gapReadyAt by remember { mutableStateOf(0L) }

    val accounts = remember { mutableStateListOf<AccountUi>().apply { repeat(10) { add(AccountUi(it + 1)) } } }
    val managers = remember { mutableStateMapOf<Int, TdLibAccount>() }
    val now by produceState(System.currentTimeMillis()) { while (true) { value = System.currentTimeMillis(); delay(1000) } }
    val account = accounts.first { it.id == selectedAccount }
    val cooldownRemaining = (account.cooldownUntil - now).coerceAtLeast(0L)
    val gapRemaining = (gapReadyAt - now).coerceAtLeast(0L)

    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF129BFF), secondary = Color(0xFF00D8FF))) {
        Box(Modifier.fillMaxSize()) {
            Image(painterResource(R.drawable.syndicate_bg), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .68f)))
            Scaffold(containerColor = Color.Transparent, topBar = {
                TopAppBar(title = { Text("ADD MEMBER GROUP SYNDICATE 411") })
            }) { pad ->
                LazyColumn(Modifier.padding(pad).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = .72f)), shape = RoundedCornerShape(16.dp)) {
                            Column(Modifier.padding(14.dp)) {
                                Text("DIRECT ADD • MANUAL CONTROL", style = MaterialTheme.typography.titleLarge)
                                Text("Akun dan grup dapat diganti tanpa menghapus status cooldown masing-masing akun.", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    item {
                        OutlinedTextField(apiId, { apiId = it }, Modifier.fillMaxWidth(), label = { Text("Telegram API ID") })
                        Spacer(Modifier.height(6.dp))
                        OutlinedTextField(apiHash, { apiHash = it }, Modifier.fillMaxWidth(), label = { Text("Telegram API Hash") })
                        Spacer(Modifier.height(6.dp))
                        OutlinedTextField(group, { group = it }, Modifier.fillMaxWidth(), label = { Text("Grup: @username atau Chat ID") })
                    }
                    item {
                        Text("Pilih akun", style = MaterialTheme.typography.titleMedium)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            (1..5).forEach { id -> FilterChip(selectedAccount == id, { selectedAccount = id }, { Text("A$id") }) }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            (6..10).forEach { id -> FilterChip(selectedAccount == id, { selectedAccount = id }, { Text("A$id") }) }
                        }
                    }
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = .76f))) {
                            Column(Modifier.padding(14.dp)) {
                                Text("Akun $selectedAccount • ${account.status}", style = MaterialTheme.typography.titleMedium)
                                Text("Berhasil: ${account.done} • Tidak dapat ditambahkan: ${account.failed} • Progress: ${account.done + account.failed}/20")
                                if (cooldownRemaining > 0) {
                                    Text("COOLDOWN: ${cooldownRemaining / 3600000}j ${(cooldownRemaining / 60000) % 60}m ${(cooldownRemaining / 1000) % 60}d")
                                } else Text("Status cooldown: siap")
                            }
                        }
                    }
                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                val id = apiId.toIntOrNull()
                                if (id == null || apiHash.isBlank()) status = "Masukkan API ID dan API Hash terlebih dahulu."
                                else {
                                    managers[selectedAccount]?.close()
                                    val manager = TdLibAccount(context, selectedAccount, id, apiHash,
                                        { msg -> status = msg },
                                        { auth ->
                                            val idx = accounts.indexOfFirst { it.id == selectedAccount }
                                            if (idx >= 0) accounts[idx] = accounts[idx].copy(connected = auth == "READY", status = when (auth) { "READY" -> "TERHUBUNG"; "CODE" -> "Menunggu kode"; "PASSWORD" -> "Menunggu password 2FA"; else -> accounts[idx].status })
                                            if (auth == "PHONE" || auth == "CODE" || auth == "PASSWORD") { authInputType = auth; dialogSlot = selectedAccount }
                                        })
                                    managers[selectedAccount] = manager
                                    manager.start()
                                }
                            }, Modifier.weight(1f)) { Text("LOGIN / GANTI AKUN") }
                            OutlinedButton(onClick = { managers[selectedAccount]?.close(); status = "Akun $selectedAccount diputuskan." }, Modifier.weight(1f)) { Text("PUTUS") }
                        }
                    }
                    item {
                        Text("Kontak target (maks. 20)", style = MaterialTheme.typography.titleMedium)
                        OutlinedTextField(username, { username = it }, Modifier.fillMaxWidth(), label = { Text("Username kontak, contoh @namauser") })
                        Spacer(Modifier.height(6.dp))
                        Text("Setiap penambahan dilakukan dari tombol manual. Jeda 5 detik diterapkan sebagai pengaman antar percobaan; aplikasi tidak melanjutkan sendiri setelah cooldown.", style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(6.dp))
                        Button(enabled = account.connected && cooldownRemaining == 0L && gapRemaining == 0L && username.isNotBlank() && account.done + account.failed < 10,
                            onClick = {
                                managers[selectedAccount]?.addMember(group, username) { result ->
                                    status = result
                                    val ok = result.startsWith("BERHASIL")
                                    val idx = accounts.indexOfFirst { it.id == selectedAccount }
                                    if (idx >= 0) {
                                        val old = accounts[idx]
                                        val nd = if (ok) old.done + 1 else old.done
                                        val nf = if (ok) old.failed else old.failed + 1
                                        accounts[idx] = old.copy(done = nd, failed = nf)
                                        if (nd + nf == 10) accounts[idx] = accounts[idx].copy(cooldownUntil = System.currentTimeMillis() + 6 * 60 * 60 * 1000L, status = "COOLDOWN 6 JAM")
                                    }
                                    gapReadyAt = System.currentTimeMillis() + 5000L
                                    username = ""
                                }
                            }, Modifier.fillMaxWidth()) { Text(if (gapRemaining > 0) "TUNGGU ${gapRemaining / 1000}s" else "TAMBAH LANGSUNG") }
                    }
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = .76f))) {
                            Column(Modifier.padding(14.dp)) {
                                Text("POLA KERJA", style = MaterialTheme.typography.titleMedium)
                                Text("• 10 kontak pertama diproses manual, jeda 5 detik antar percobaan.\n• Setelah 10 percobaan, cooldown 6 jam.\n• Setelah cooldown selesai, Anda menekan tombol untuk melanjutkan 10 berikutnya.\n• Setelah 20 selesai, cooldown 6 jam sebelum batch baru.\n• Kontak yang tidak dapat ditambahkan dicatat sebagai gagal/skip.\n• Cooldown tersimpan per akun dan tidak berubah saat akun/grup diganti.")
                            }
                        }
                    }
                    item { Text(status, style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
    }

    if (dialogSlot != null) {
        AlertDialog(onDismissRequest = { dialogSlot = null }, title = { Text("Login akun $dialogSlot") }, text = {
            Column {
                Text("Tahap: $authInputType")
                Spacer(Modifier.height(8.dp))
                when (authInputType) {
                    "PHONE" -> OutlinedTextField(phoneInput, { phoneInput = it }, Modifier.fillMaxWidth(), label = { Text("Nomor Telegram +62...") })
                    "CODE" -> OutlinedTextField(codeInput, { codeInput = it }, Modifier.fillMaxWidth(), label = { Text("Kode Telegram") })
                    "PASSWORD" -> OutlinedTextField(passwordInput, { passwordInput = it }, Modifier.fillMaxWidth(), label = { Text("Password 2FA") }, visualTransformation = PasswordVisualTransformation())
                }
            }
        }, confirmButton = { TextButton(onClick = {
            val slot = dialogSlot ?: return@TextButton
            when (authInputType) { "PHONE" -> managers[slot]?.setPhone(phoneInput); "CODE" -> managers[slot]?.setCode(codeInput); "PASSWORD" -> managers[slot]?.setPassword(passwordInput) }
            dialogSlot = null
        }) { Text("Kirim") } }, dismissButton = { TextButton(onClick = { dialogSlot = null }) { Text("Tutup") } })
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel(applicationContext)
        setContent { App(applicationContext) }
    }
}
