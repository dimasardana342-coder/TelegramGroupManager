package com.example.telegramgroupmanager

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.drinkless.tdlib.Client
import org.drinkless.tdlib.TdApi
import java.io.File

class TdLibAccount(
    private val context: Context,
    private val slot: Int,
    private val apiId: Int,
    private val apiHash: String,
    private val onStatus: (String) -> Unit,
    private val onAuthState: (String) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private var client: Client? = null
    private var phoneNumber: String = ""

    fun start() {
        if (client != null) return
        try {
            Client.execute(TdApi.SetLogVerbosityLevel(0))
        } catch (_: Throwable) { }

        client = Client.create(
            Client.ResultHandler { objectResult -> handleUpdate(objectResult) },
            Client.ExceptionHandler { error -> post("TDLib update error: ${error.message}") },
            Client.ExceptionHandler { error -> post("TDLib error: ${error.message}") }
        )
        post("Akun $slot: TDLib dimulai")
    }

    fun setPhone(phone: String) {
        phoneNumber = phone.trim()
        if (client == null) start()
        client?.send(
            TdApi.SetAuthenticationPhoneNumber(phoneNumber, null),
            Client.ResultHandler { result ->
                if (result is TdApi.Error) post("Gagal kirim nomor: ${result.code} ${result.message}")
            }
        )
    }

    fun setCode(code: String) {
        client?.send(
            TdApi.CheckAuthenticationCode(code.trim()),
            Client.ResultHandler { result ->
                if (result is TdApi.Error) post("Kode ditolak: ${result.code} ${result.message}")
            }
        )
    }

    fun setPassword(password: String) {
        client?.send(
            TdApi.CheckAuthenticationPassword(password),
            Client.ResultHandler { result ->
                if (result is TdApi.Error) post("Password ditolak: ${result.code} ${result.message}")
            }
        )
    }

    fun addMember(group: String, username: String, callback: (String) -> Unit) {
        val cleanGroup = group.trim()
        val cleanUser = username.trim().removePrefix("@").trim()
        if (cleanGroup.isBlank() || cleanUser.isBlank()) {
            callback("Isi grup dan username terlebih dahulu")
            return
        }
        val groupChat = parseLongOrNull(cleanGroup)
        if (groupChat != null) {
            resolveUserAndAdd(groupChat, cleanUser, callback)
        } else {
            client?.send(TdApi.SearchPublicChat(cleanGroup.removePrefix("@")), Client.ResultHandler { result ->
                if (result is TdApi.Chat) {
                    resolveUserAndAdd(result.id, cleanUser, callback)
                } else if (result is TdApi.Error) {
                    callback("Grup tidak ditemukan: ${result.code} ${result.message}")
                }
            }) ?: callback("Akun belum login")
        }
    }

    private fun resolveUserAndAdd(groupChatId: Long, username: String, callback: (String) -> Unit) {
        client?.send(TdApi.SearchPublicChat(username), Client.ResultHandler { result ->
            if (result is TdApi.Chat) {
                val type = result.type
                if (type is TdApi.ChatTypePrivate) {
                    val userId = type.userId
                    client?.send(TdApi.AddChatMember(groupChatId, userId, 0), Client.ResultHandler { addResult ->
                        if (addResult is TdApi.Ok) {
                            callback("BERHASIL: @$username ditambahkan ke $groupChatId")
                        } else if (addResult is TdApi.Error) {
                            callback("GAGAL @$username: ${addResult.code} ${addResult.message}")
                        } else {
                            callback("Hasil tidak dikenal untuk @$username: $addResult")
                        }
                    })
                } else {
                    callback("@$username bukan akun pengguna")
                }
            } else if (result is TdApi.Error) {
                callback("User @$username tidak ditemukan: ${result.code} ${result.message}")
            }
        }) ?: callback("Akun belum login")
    }

    fun close() {
        client?.close()
        client = null
    }

    private fun handleUpdate(result: TdApi.Object) {
        when (result) {
            is TdApi.UpdateAuthorizationState -> handleAuth(result.authorizationState)
            is TdApi.UpdateConnectionState -> {
                val state = result.state
                post("Koneksi akun $slot: ${state.javaClass.simpleName}")
            }
        }
    }

    private fun handleAuth(state: TdApi.AuthorizationState) {
        when (state) {
            is TdApi.AuthorizationStateWaitTdlibParameters -> {
                val db = File(context.filesDir, "tdlib/account_$slot")
                val files = File(db, "files")
                val parameters = TdApi.TdlibParameters(
                    false,
                    db.absolutePath,
                    files.absolutePath,
                    true,
                    true,
                    true,
                    false,
                    apiId,
                    apiHash,
                    "id",
                    "TelegramGroupManager",
                    android.os.Build.VERSION.RELEASE,
                    "3.0",
                    true,
                    false
                )
                client?.send(TdApi.SetTdlibParameters(parameters), Client.ResultHandler { result ->
                    if (result is TdApi.Error) post("Parameter Telegram gagal: ${result.code} ${result.message}")
                })
            }
            is TdApi.AuthorizationStateWaitPhoneNumber -> {
                post("Akun $slot: masukkan nomor Telegram")
                onAuth("PHONE")
            }
            is TdApi.AuthorizationStateWaitCode -> {
                post("Akun $slot: kode Telegram diperlukan")
                onAuth("CODE")
            }
            is TdApi.AuthorizationStateWaitPassword -> {
                post("Akun $slot: password 2FA diperlukan")
                onAuth("PASSWORD")
            }
            is TdApi.AuthorizationStateReady -> {
                post("Akun $slot: TERHUBUNG")
                onAuth("READY")
            }
            is TdApi.AuthorizationStateLoggingOut -> onAuth("LOGGING_OUT")
            is TdApi.AuthorizationStateClosing -> onAuth("CLOSING")
            is TdApi.AuthorizationStateClosed -> onAuth("CLOSED")
        }
    }

    private fun parseLongOrNull(value: String): Long? = value.toLongOrNull()

    private fun post(message: String) {
        main.post { onStatus(message) }
    }

    private fun onAuth(value: String) {
        main.post { onAuthState(value) }
    }
}
