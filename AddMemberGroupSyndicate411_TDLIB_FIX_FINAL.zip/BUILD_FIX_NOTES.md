# Build fix

The previous build failed because `TdLibAccount.kt` imports the classic Java TDLib API (`org.drinkless.td.libcore.telegram.Client` / `TdApi`), while the Maven Central `io.github.tdlibx:td-android:1.8.56-RC9` artifact is a newer Kotlin Multiplatform Android artifact that does not expose those classes under the expected package.

This revision uses the classic TDLib Android Java library published by tdlibx through JitPack, matching the API used by `TdLibAccount.kt`: `com.github.tdlibx:td:1.8.56`. The JitPack repository is added in `settings.gradle.kts`.

This fixes the specific `Unresolved reference 'TdApi'`, `Client`, `send`, `code`, and `message` compiler errors shown in GitHub Actions.
