# Build fix

This revision aligns the Kotlin compiler/plugin with TDLibX 1.8.56-RC9, which is published with Kotlin 2.2.x, while keeping Android Gradle Plugin 8.9.1 and JDK 17.

The app remains Android 13+ (minSdk 33), target/compile SDK 36.
