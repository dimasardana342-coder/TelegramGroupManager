package com.example.telegramgroupmanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class Account(
    val id: Int,
    var group: String = "Belum dipilih",
    var connected: Boolean = false,
    var queue: Int = 0,
    var paused: Boolean = false
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val accounts = remember {
        mutableStateListOf<Account>().apply { repeat(10) { add(Account(it + 1)) } }
    }
    var status by remember {
        mutableStateOf("Maksimal 10 akun dan 10 grup. Slot tidak wajib digunakan semua.")
    }

    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("Telegram Group Manager") }) }) { pad ->
            Column(Modifier.padding(pad).padding(16.dp).fillMaxSize()) {
                Text("Akun & Grup", style = MaterialTheme.typography.headlineSmall)
                Spacer(Modifier.height(6.dp))
                Text(status, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(12.dp))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(accounts) { a ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp)) {
                                Text("Akun ${a.id}", style = MaterialTheme.typography.titleMedium)
                                Text(if (a.connected) "Terhubung" else "Belum terhubung")
                                Text("Grup: ${a.group}")
                                Text("Antrean: ${a.queue}")
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = {
                                        a.connected = true
                                        status = "Akun ${a.id}: status siap untuk integrasi TDLib."
                                    }) { Text("Login") }
                                    OutlinedButton(onClick = {
                                        a.queue += 10
                                        status = "Akun ${a.id}: 10 item ditambahkan ke antrean."
                                    }) { Text("+10") }
                                    OutlinedButton(onClick = {
                                        a.paused = !a.paused
                                        status = "Akun ${a.id}: " + if (a.paused) "pause" else "lanjut"
                                    }) { Text(if (a.paused) "Lanjut" else "Pause") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}
