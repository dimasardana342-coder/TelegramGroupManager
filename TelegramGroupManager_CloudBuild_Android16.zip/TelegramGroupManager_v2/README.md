# Telegram Group Manager v2

Target Android 16 (API 36).

Versi ini menyediakan:
- Maksimal 10 slot akun.
- Maksimal 10 slot grup.
- Tidak wajib menggunakan semua slot.
- Status akun, grup, antrean, dan pause.
- Struktur awal untuk integrasi TDLib.

Integrasi Telegram nyata memerlukan api_id dan api_hash milik aplikasi Anda.
TDLib menangani authorization, penyimpanan lokal, sinkronisasi, dan komunikasi
dengan Telegram.

Catatan: versi ini tidak mengotomatisasi random-add atau mengakali sistem
anti-spam Telegram. Antrean dapat digunakan untuk anggota yang memang telah
memberikan persetujuan untuk dimasukkan.

Buka folder ini dengan Android Studio, sync Gradle, pastikan SDK 36 terpasang,
lalu Build > Build APK(s).
