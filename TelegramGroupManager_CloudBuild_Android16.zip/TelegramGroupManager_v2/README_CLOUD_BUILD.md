# Telegram Group Manager v2 — Cloud Build

Project ini sudah disiapkan untuk **build APK Android 16 (API 36)** menggunakan GitHub Actions dari HP, tanpa laptop/PC.

## Cara build dari HP

1. Buat akun/login di GitHub.
2. Buat repository baru, misalnya `TelegramGroupManager`.
3. Upload **isi folder project ini** ke repository (bukan file ZIP sebagai satu file).
4. Pastikan folder `.github/workflows/build-apk.yml` ikut ter-upload.
5. Buka tab **Actions** → pilih **Build Android APK** → **Run workflow**.
6. Tunggu sampai proses selesai.
7. Buka hasil workflow → bagian **Artifacts** → download `TelegramGroupManager-debug`.
8. Extract ZIP artifact tersebut. Di dalamnya ada `app-debug.apk`.
9. Pasang APK di HP Android 16.

## Spesifikasi

- compileSdk 36
- targetSdk 36
- minSdk 26
- AGP 8.9.1
- Gradle 8.11.1
- JDK 17
- Maksimal 10 akun dan 10 grup.

## Catatan

Versi ini adalah UI/queue scaffold. Belum terhubung ke akun Telegram asli. Integrasi Telegram nyata memerlukan TDLib/Telegram API dan `api_id`/`api_hash`.

Fitur antrean harus digunakan untuk aktivitas yang sah dan berbasis persetujuan. Project ini tidak dirancang untuk mengakali pembatasan atau sistem anti-spam Telegram.
